package Ingredientes;

public class Frutas extends Ingredientes{

	public Frutas(){
		super();
	}
}
