package Ingredientes;

public class Ingredientes {
	private String Name;
	
	public Ingredientes(){
		
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}
	
	

}
