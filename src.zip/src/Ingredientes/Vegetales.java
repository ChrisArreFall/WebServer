package Ingredientes;

public class Vegetales extends Ingredientes{
	public Vegetales(){
		super();
	}

}
