package Ingredientes;

public class Carnes extends Ingredientes{
	public Carnes(){
		super();
	}

}
