package Ingredientes;

public class Granos extends Ingredientes{
	public Granos(){
		super();
	}

}
