package Ingredientes;

public class Lacteos extends Ingredientes{
	public Lacteos(){
		super();
	}

}
